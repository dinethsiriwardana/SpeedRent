<?php 

if(!isset($_COOKIE['UID'])) {

    header("location: ./login.php");

}

?>



<?php


$sql = "SELECT CONCAT(ua.fname, ' ', ua.lname) AS full_name, SUM(ro.price) AS total_amount FROM rent_order ro JOIN user_accounts ua ON ro.uid = ua.uid GROUP BY ua.fname, ua.lname;";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {


        echo '  <div class="row" style="margin-bottom: 15px;">
                    <div class="col-md-4 col-xxl-2 d-xxl-flex align-items-xxl-center">
                        <div>
                            <h6 class="text-muted mb-2" style="font-size: 15px;color: rgba(0,0,0,0.25);">User ID</h6>
                            <h4 style="font-size: 25px;">10234</h4>
                        </div>
                    </div>
                    <div class="col-md-4 col-xxl-6 d-xxl-flex align-items-xxl-center">
                        <div>
                            <h6 class="text-muted mb-2" style="font-size: 15px;color: rgba(0,0,0,0.25);">Name</h6>
                            <h4 class="text-truncate" style="font-size: 25px;">' . $row['full_name'] . '</h4>
                        </div>
                    </div>
                    <div class="col-md-4 col-xl-3 col-xxl-3 d-xxl-flex align-items-xxl-center">
                        <div>
                            <h6 class="text-muted mb-2" style="font-size: 15px;color: rgba(0,0,0,0.25);">Income</h6>
                            <h4 style="font-size: 25px;">$' . $row['total_amount'] . '</h4>
                        </div>
                    </div>

            </div>';
    }
}

?>